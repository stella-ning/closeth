﻿<?php

return array(
    'name'      => '淘宝网',
    'version'   => '1.0',
    'author'    => '淘友爱',
    'description'=> 'style',
);

?>