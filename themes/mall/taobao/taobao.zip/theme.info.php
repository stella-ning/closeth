﻿<?php

return array(
    'version'       => '1.0',
    'author'        => '淘友爱',
    'description'   => 'yes',
);

?>